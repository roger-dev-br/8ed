const Home: React.FC = () => {
  return (
    <>
      <h1>Aula 4</h1>
      <hr />
    </>
  );
};

export default Home;
