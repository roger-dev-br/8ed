const Recado: React.FC = () => {
    return (
        <h1>Recados</h1>
    );
}

export default Recado;